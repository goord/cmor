#!/bin/sh
#SBATCH -N1
#SBATCH -n1		
#SBATCH --exclusive
##SBATCH --reservation=schaikv_5
env
set
echo "SOFTLIMIT"
ulimit -aS
echo "HARDLIMITS"
ulimit -aH
echo "Change locked memory"
ulimit -l 8388608
ulimit -l
date
sleep 300
date
