#!/bin/sh
#SBATCH -N1
#SBATCH -n1		
#SBATCH --exclusive
#SBATCH --reservation=
date
echo "SOFTLIMIT"
ulimit -aS
echo "HARDLIMITS"
ulimit -aH
echo "Setting file descriptor"
ulimit -n 2048
echo "Checking file descriptor"
ulimit -n
date
