#!/bin/bash
echo "submitting alloc test at 1 node with 1 process..."
ulimit -s 102400
sbatch -N1 -n1 --ntasks-per-node=1 --exclusive ./run.sh
