#!/bin/bash
echo "Running this simple alocation test..."
#ulimit -s 102400
./alloctest
echo "...and we're done"
