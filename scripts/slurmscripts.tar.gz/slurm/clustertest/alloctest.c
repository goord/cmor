#include <stdio.h>
#include <stdlib.h>


int main()
{
	int decimal=1024;
	int chunk_size=32;
	int bytes_per_gb=decimal*decimal*decimal;
	int i,j,k;
	for(i=1;i<25;i++)
	{
		printf("Allocating %iGB...",i);
		for(j=0;j<bytes_per_gb/(chunk_size*decimal);j++)
		{
			void* ptr=malloc(chunk_size*decimal);
			if(ptr==NULL)
			{
				printf("failure\n");
				return 1;
			}
			double* dptr=(double*)ptr;
			int dptr_size=(chunk_size*decimal)/sizeof(double);
			for(k=0;k<dptr_size;k++)
			{
				dptr[k]=3.14;
			}
		}
		printf("succes\n");
	}
	return 0;
}
