#!/bin/bash
#
#~/SCRATCH/ecearth-3/ECE3/log/001/xios_server_000.out
ECEPATH=~/SCRATCH/ecearth-3/ECE3-noexp/log


#cd $ECEPATH
for i in $(ls); do
  #echo "$i"
  cd $i;
  stats=$(cat xios_server_000.out | egrep -o [0-9.]+) #("$@")
  echo ${stats[0]}
  cd ..
done


