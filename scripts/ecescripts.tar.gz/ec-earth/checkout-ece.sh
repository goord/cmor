#!/bin/bash
checkoutdir=${HOME}/$1
echo "Checking out hires-branch to ${checkoutdir}"
svn checkout --username g.vandenoord --password 9pwmx3PtyD https://svn.ec-earth.org/ecearth3/branches/development/2016/r2811-hires ${checkoutdir}
echo "Done"
