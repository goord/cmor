#!/bin/bash

TOPDIR=$1
GRID=ORCA025L75_LIM3
CONFIGFILE=config-build.xml

echo "Building ec-earth-3.2 in directory ${TOPDIR}..."
cd ${TOPDIR}/sources

echo "Substituting path in config file..."
sed -i 's,${HOME}/BACKUP/ece-3.2b/sources,'"${TOPDIR}/sources"',g' ${CONFIGFILE}

echo "Configuring platform to neuron-intel-intelmpi..."
./util/ec-conf/ec-conf --platform neuron-intel-intelmpi ${CONFIGFILE}

echo "Building oasis3..."
cd ${TOPDIR}/sources/oasis3-mct/util/make_dir
make BUILD_ARCH=ecconf -f TopMakefileOasis3

echo "Setting g++ as C-compiler in config file..."
cd ${TOPDIR}/sources
# TODO: Make this a proper xml-edit to avoid side effects.
sed -i 's/icc/g++/g' ${CONFIGFILE}
./util/ec-conf/ec-conf --platform neuron-intel-intelmpi ${CONFIGFILE}

echo "Building xios-1.0..."
cd ${TOPDIR}/sources/xios-1.0
./make_xios --arch ecconf --use_oasis oasis3_mct --netcdf_lib netcdf4_seq --full

echo "Setting g++ as C-compiler in config file..."
cd ${TOPDIR}/sources
# TODO: Make this a proper xml-edit to avoid side effects.
sed -i 's/g++/icc/g' ${CONFIGFILE}
./util/ec-conf/ec-conf --platform neuron-intel-intelmpi ${CONFIGFILE}

echo "Building runoff-mapper..."
cd ${TOPDIR}/sources/runoff-mapper/src
make

echo "Building ifs..."
cd ${TOPDIR}/sources/ifs-36r4
make BUILD_ARCH=ecconf -j8 lib
if [ $? == 0 ]; then make BUILD_ARCH=ecconf master; fi

echo "Building NEMO..."
cd ${TOPDIR}/sources/nemo-3.6/CONFIG
./makenemo -n ${GRID} -m ecconf -j8

echo "Done."
