#!/bin/bash

TOPDIR=$1
GRID=ORCA025L75_LIM3

echo "Cleaning ec-earth-3.2 in directory ${TOPDIR}..."
LOC="${PWD}"
cd ${TOPDIR}/sources

echo "Cleaning oasis3..."
cd ${TOPDIR}/sources/oasis3-mct/util/make_dir
make BUILD_ARCH=ecconf -f TopMakefileOasis3 cleanlibs

echo "Cleaning xios-1.0..."
cd ${TOPDIR}/sources/xios-1.0
rm -rf lib/*.a
rm -rf obj/*.o
rm -rf bin/*.exe

echo "Cleaning runoff-mapper..."
cd ${TOPDIR}/sources/runoff-mapper/src
make clean
rm -rf ../bin/*.exe

echo "Cleaning ifs..."
cd ${TOPDIR}/sources/ifs-36r4
make BUILD_ARCH=ecconf clean

echo "Cleaning NEMO..."
cd ${TOPDIR}/sources/nemo-3.6/CONFIG
./makenemo -n ${GRID} -m ecconf clean

echo "Done."
cd ${LOC}
