# Platform dependent configuration functions for the 'neuron' machine
# (KNMI, NL)

hostlist="${HOME}/bin/ExpandNodeList -r -p 1"
proc_per_node=12

# version using the hydra process manager
cmd="mpi-command"

nodelist="neuron[1-21]"
nodes="$(${hostlist} $nodelist)"

echo "The node list is $nodes"

echo "The processes will be distributed according to "
while (( "$#" ))
do
	nranks=$1
        executable=./$(basename $2)
	shift
	shift
	cmd+=" -n $nranks $executable"
	while (( "$#" )) && [ "$1" != "--" ]
	do
	cmd+=" $1"
	shift
	done
	shift || true
	
	echo "the starting rank is $nranks, the nodes are $nodes........."

	for node in $nodes
	do
		(( n = proc_per_node<nranks?proc_per_node:nranks ))
		for ((i = 1; i<= n; i++));do echo "$node"; done
		(( nranks -= n )) || break
	done
	
	nodes=$(echo $nodes | sed "s/.*$node[[:space:]]*//")
	(( "$#" )) && cmd+=" :"
	done
