#!/bin/bash
EC_EARTH_DIR=${HOME}/ece-hires

cd ${EC_EARTH_DIR}/runtime/classic/

${EC_EARTH_DIR}/sources/util/ec-conf/ec-conf -p neuron config-run-hires.xml

expn=$(get_ece_config_param.py config-run-hires.xml GENERAL EXP_NAME) || return 1
nifs=$(get_ece_config_param.py config-run-hires.xml IFS NUMPROC) || return 1
nnem=$(get_ece_config_param.py config-run-hires.xml NEM NUMPROC) || return 1
nxio=$(get_ece_config_param.py config-run-hires.xml XIO NUMPROC) || return 1
ppno=$(get_ece_config_param.py config-run-hires.xml neuron PROC_PER_NODE) || return 1 

totprocs=$((nifs+nnem+nxio+1))
totnodes=$(( totprocs/ppno ))
(( totprocs % ppno )) && (( totnodes+=2 ))
ulimit -s 102400
sbatch -N${totnodes} -n${totprocs} --ntasks-per-node=${ppno} ./ece-ifs+nemo.sh
cd -
